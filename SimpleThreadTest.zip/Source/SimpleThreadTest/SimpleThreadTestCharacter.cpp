// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "SimpleThreadTestCharacter.h"
#include "HeadMountedDisplayFunctionLibrary.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Controller.h"
#include "GameFramework/SpringArmComponent.h"
#include "ThreadManage.h"

//////////////////////////////////////////////////////////////////////////
// ASimpleThreadTestCharacter
//��
FCriticalSection					Mutex;

//��ӡ
void ThreadP(const FString &Mes)
{
	FScopeLock ScopeLock(&Mutex);
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 4.f, FColor::Red, *Mes);
	}
}

//�ṹ��
struct FTestStruct
{
	void Hello(FString Mes)
	{
		ThreadP(FString::Printf(TEXT("FTestStruct::Hello : %s"), *Mes));
	}
};

//����ָ��
struct FTestStructSP :public TSharedFromThis<FTestStructSP>
{
	void HelloSP(FString Mes)
	{
		ThreadP(FString::Printf(TEXT("FTestStructSP::Hello : %s"), *Mes));
	}
};

ASimpleThreadTestCharacter::ASimpleThreadTestCharacter()
{
	// Set size for collision capsule
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);

	// set our turn rates for input
	BaseTurnRate = 45.f;
	BaseLookUpRate = 45.f;

	// Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	// Configure character movement
	GetCharacterMovement()->bOrientRotationToMovement = true; // Character moves in the direction of input...	
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 540.0f, 0.0f); // ...at this rotation rate
	GetCharacterMovement()->JumpZVelocity = 600.f;
	GetCharacterMovement()->AirControl = 0.2f;

	// Create a camera boom (pulls in towards the player if there is a collision)
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = 300.0f; // The camera follows at this distance behind the character	
	CameraBoom->bUsePawnControlRotation = true; // Rotate the arm based on the controller

	// Create a follow camera
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName); // Attach the camera to the end of the boom and let the boom adjust to match the controller orientation
	FollowCamera->bUsePawnControlRotation = false; // Camera does not rotate relative to arm

	// Note: The skeletal mesh and anim blueprint references on the Mesh component (inherited from Character) 
	// are set in the derived blueprint asset named MyCharacter (to avoid direct content references in C++)
}

FTestStruct MyStruct;
TSharedPtr<FTestStructSP> MyStructSP = MakeShareable(new FTestStructSP);
TArray<FThreadHandle> ThreadHandle;
FTimerHandle Handle;
FTimerHandle Handle2;
void ASimpleThreadTestCharacter::ThreadProxyManageBind()
{
	ThreadHandle.Empty();
	ThreadHandle.SetNum(5);

	ThreadHandle[0] = GThread::GetProxy().BindUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	ThreadHandle[1] = GThread::GetProxy().BindRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	ThreadHandle[2] = GThread::GetProxy().BindSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	ThreadHandle[3] = GThread::GetProxy().BindUFunction(this, TEXT("TestUFunction"), 123, "TestUFunction1");
	ThreadHandle[4] = GThread::GetProxy().BindLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");


	GetWorld()->GetTimerManager().SetTimer(Handle, this, &ASimpleThreadTestCharacter::TimeCall, 3.f);
}

void ASimpleThreadTestCharacter::ThreadProxyManageCreate()
{
	GThread::GetProxy().CreateUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	GThread::GetProxy().CreateRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	GThread::GetProxy().CreateSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	GThread::GetProxy().CreateUFunction(this, TEXT("TestUFunction"), 123, "TestUFunction");
	GThread::GetProxy().CreateLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::ThreadTaskManagementBind()
{
	GThread::GetTask().BindUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	GThread::GetTask().BindRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	GThread::GetTask().BindSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	GThread::GetTask().BindUFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	GThread::GetTask().BindLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::ThreadTaskManagementCreate()
{
	GThread::GetTask().CreateUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	GThread::GetTask().CreateRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	GThread::GetTask().CreateSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	GThread::GetTask().CreateUFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	GThread::GetTask().CreateLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::ThreadAbandonableManageBind()
{
	GThread::GetAbandonable().BindUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	GThread::GetAbandonable().BindRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	GThread::GetAbandonable().BindSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	GThread::GetAbandonable().BindUFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	GThread::GetAbandonable().BindLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::ThreadAbandonableManageCreate()
{
	GThread::GetAbandonable().CreateUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	GThread::GetAbandonable().CreateRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	GThread::GetAbandonable().CreateSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	GThread::GetAbandonable().CreateUFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	GThread::GetAbandonable().CreateLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::SynchronousMacro()
{
	SYNCTASK_UOBJECT(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	SYNCTASK_Raw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	SYNCTASK_SP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	SYNCTASK_UFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	SYNCTASK_Lambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::AsynchronousMacro()
{
	ASYNCTASK_UOBJECT(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	ASYNCTASK_Raw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	ASYNCTASK_SP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	ASYNCTASK_UFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	ASYNCTASK_Lambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");

}

void ASimpleThreadTestCharacter::CoroutinesManageBind()
{
	//����1s��ִ�к���T1
	GThread::GetCoroutines().BindUObject(1.f, this, &ASimpleThreadTestCharacter::TestUObject, 777);
	GThread::GetCoroutines().BindRaw(2.f, &MyStruct, &FTestStruct::Hello, FString("Hello~"));
	GThread::GetCoroutines().BindSP(2.4f, MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	GThread::GetCoroutines().BindUFunction(4.f, this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	GThread::GetCoroutines().BindLambda(7.f, [](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");

}

TArray<FCoroutinesHandle> CoroutinesHandle;
void ASimpleThreadTestCharacter::CoroutinesManageCreate()
{
	CoroutinesHandle.SetNum(5);
	CoroutinesHandle[0] = GThread::GetCoroutines().CreateUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	CoroutinesHandle[1] = GThread::GetCoroutines().CreateRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	CoroutinesHandle[2] = GThread::GetCoroutines().CreateSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	CoroutinesHandle[3] = GThread::GetCoroutines().CreateUFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	CoroutinesHandle[4] = GThread::GetCoroutines().CreateLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");

	GetWorld()->GetTimerManager().SetTimer(Handle2, this, &ASimpleThreadTestCharacter::CoroutinesCall, 3.f);
}

#include "WindowsPlatformThread.h"
void ASimpleThreadTestCharacter::WindowsPlatformThread()
{
	FWindowsPlatformThread::RunDelegate.BindUObject(this, &ASimpleThreadTestCharacter::Run);
	FWindowsPlatformThread::CompletedDelegate.BindUObject(this, &ASimpleThreadTestCharacter::OK);
	FWindowsPlatformThread::Show();//ִ���߳�
}

TSharedPtr<FStreamableHandle> StreamableHandle = nullptr;
void ASimpleThreadTestCharacter::ResourceLoadingManageSynch()
{
	auto La = [](TSharedPtr<FStreamableHandle> *InHandle)
	{
		TArray<UObject *> ExampleObject;
		(*InHandle)->GetLoadedAssets(ExampleObject);

		for (UObject *Tmp : ExampleObject)
		{
			ThreadP(Tmp->GetName());
		}
	};

	//ͬ��
   //////////////////////////////////////////////////////////////////////////
	StreamableHandle = GThread::GetResourceLoading() << ObjectPath;
	La(&StreamableHandle);
}

void ASimpleThreadTestCharacter::ResourceLoadingManageASynch()
{
	auto La = [](TSharedPtr<FStreamableHandle> *InHandle)
	{
		TArray<UObject *> ExampleObject;
		(*InHandle)->GetLoadedAssets(ExampleObject);

		for (UObject *Tmp : ExampleObject)
		{
			ThreadP(Tmp->GetName());
		}
	};

	//�첽ʹ�÷���
	GThread::GetResourceLoading() >> ObjectPath;
	StreamableHandle = GThread::GetResourceLoading().CreateLambda(La, &StreamableHandle);
}

TArray<FGraphEventRef > ArrayEventRef;
void ASimpleThreadTestCharacter::ThreadGraphManage_CallMainTread()
{
	ArrayEventRef.SetNum(5);
	ArrayEventRef[0] = GThread::GetGraph().BindUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	ArrayEventRef[1] = GThread::GetGraph().BindRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	ArrayEventRef[2] = GThread::GetGraph().BindSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	ArrayEventRef[3] = GThread::GetGraph().BindUFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	ArrayEventRef[4] = GThread::GetGraph().BindLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");

	//GThread::GetGraph().Wait(ArrayEventRef[0]);
	FGraphEventArray ArrayEvent;
	for (auto &Tmp : ArrayEventRef)
	{
		ArrayEvent.Add(Tmp);
	}

	//You can set to wait for these threads to complete their tasks before executing themselves 
	GThread::GetGraph().Wait(ArrayEvent);
	ThreadP("Wait-oK");

}

void ASimpleThreadTestCharacter::ThreadGraphManage_CallAnyThread()
{
	GThread::GetGraph().CreateUObject(this, &ASimpleThreadTestCharacter::TestUObject, 777);
	GThread::GetGraph().CreateRaw(&MyStruct, &FTestStruct::Hello, FString("Hello~"));
	GThread::GetGraph().CreateSP(MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	GThread::GetGraph().CreateUFunction(this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	GThread::GetGraph().CreateLambda([](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::OtherThread()
{
	auto A = CALL_THREAD_UOBJECT(NULL, ENamedThreads::AnyThread, this, &ASimpleThreadTestCharacter::TestUObject, 777);

	//�ȴ�A�¼����ִ��B�¼�
	auto B = CALL_THREAD_Raw(A, ENamedThreads::AnyThread, &MyStruct, &FTestStruct::Hello, FString("Hello~"));
	auto C = CALL_THREAD_SP(NULL, ENamedThreads::AnyThread, MyStructSP.ToSharedRef(), &FTestStructSP::HelloSP, FString("HelloSP~"));
	auto D = CALL_THREAD_UFunction(nullptr,ENamedThreads::AnyThread, this, TEXT("TestUFunction"), 123, FString("TestUFunction"));
	auto E = CALL_THREAD_Lambda(NULL, ENamedThreads::AnyThread, [](FString Mes)
	{
		ThreadP(Mes);
	}, "Lambda");
}

void ASimpleThreadTestCharacter::TestUObject(int32 Value)
{
	ThreadP(FString::Printf(TEXT("TestUObject (%i)"), Value));
}

void ASimpleThreadTestCharacter::TestUFunction(int32 Value, FString Mes)
{
	ThreadP(FString::Printf(TEXT("TestUFunction (%i,%s)"), Value,*Mes));
}

void ASimpleThreadTestCharacter::TimeCall()
{
	if (Handle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(Handle);
	}

	//Synchronous execution 
	for (auto &Tmp : ThreadHandle)
	{
		GThread::GetProxy().Join(Tmp);
	}

	//Asynchronous execution 
	//for (auto &Tmp : ThreadHandle)
	//{
	//	GThread::GetProxy().Detach(Tmp);
	//}
}

void ASimpleThreadTestCharacter::CoroutinesCall()
{
	if (Handle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(Handle2);
	}

	for (auto &Tmp : CoroutinesHandle)
	{
		if (Tmp.IsValid())
		{
			//Wake up the events under this protocol 
			Tmp.Pin()->Awaken();
		}
	}
}

void ASimpleThreadTestCharacter::Run()
{
	ThreadP(TEXT("Windows Run()"));
}

void ASimpleThreadTestCharacter::OK()
{
	ThreadP(TEXT("Windows OK()"));
}

//////////////////////////////////////////////////////////////////////////
// Input

void ASimpleThreadTestCharacter::SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent)
{
	// Set up gameplay key bindings
	check(PlayerInputComponent);
	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &ACharacter::Jump);
	PlayerInputComponent->BindAction("Jump", IE_Released, this, &ACharacter::StopJumping);

	PlayerInputComponent->BindAxis("MoveForward", this, &ASimpleThreadTestCharacter::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &ASimpleThreadTestCharacter::MoveRight);

	// We have 2 versions of the rotation bindings to handle different kinds of devices differently
	// "turn" handles devices that provide an absolute delta, such as a mouse.
	// "turnrate" is for devices that we choose to treat as a rate of change, such as an analog joystick
	PlayerInputComponent->BindAxis("Turn", this, &APawn::AddControllerYawInput);
	PlayerInputComponent->BindAxis("TurnRate", this, &ASimpleThreadTestCharacter::TurnAtRate);
	PlayerInputComponent->BindAxis("LookUp", this, &APawn::AddControllerPitchInput);
	PlayerInputComponent->BindAxis("LookUpRate", this, &ASimpleThreadTestCharacter::LookUpAtRate);

	// handle touch devices
	PlayerInputComponent->BindTouch(IE_Pressed, this, &ASimpleThreadTestCharacter::TouchStarted);
	PlayerInputComponent->BindTouch(IE_Released, this, &ASimpleThreadTestCharacter::TouchStopped);

	// VR headset functionality
	PlayerInputComponent->BindAction("ResetVR", IE_Pressed, this, &ASimpleThreadTestCharacter::OnResetVR);
}


void ASimpleThreadTestCharacter::OnResetVR()
{
	UHeadMountedDisplayFunctionLibrary::ResetOrientationAndPosition();
}

void ASimpleThreadTestCharacter::TouchStarted(ETouchIndex::Type FingerIndex, FVector Location)
{
		Jump();
}

void ASimpleThreadTestCharacter::TouchStopped(ETouchIndex::Type FingerIndex, FVector Location)
{
		StopJumping();
}

void ASimpleThreadTestCharacter::TurnAtRate(float Rate)
{
	// calculate delta for this frame from the rate information
	AddControllerYawInput(Rate * BaseTurnRate * GetWorld()->GetDeltaSeconds());
}

void ASimpleThreadTestCharacter::LookUpAtRate(float Rate)
{
	// calculate delta for this frame from the rate information
	AddControllerPitchInput(Rate * BaseLookUpRate * GetWorld()->GetDeltaSeconds());
}

void ASimpleThreadTestCharacter::MoveForward(float Value)
{
	if ((Controller != NULL) && (Value != 0.0f))
	{
		// find out which way is forward
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);

		// get forward vector
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		AddMovementInput(Direction, Value);
	}
}

void ASimpleThreadTestCharacter::MoveRight(float Value)
{
	if ( (Controller != NULL) && (Value != 0.0f) )
	{
		// find out which way is right
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);
	
		// get right vector 
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		// add movement in that direction
		AddMovementInput(Direction, Value);
	}
}
