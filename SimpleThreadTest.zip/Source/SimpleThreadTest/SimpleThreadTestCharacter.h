// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Engine/StreamableManager.h"
#include "SimpleThreadTestCharacter.generated.h"


UCLASS(config=Game)
class ASimpleThreadTestCharacter : public ACharacter
{
	GENERATED_BODY()

	/** Camera boom positioning the camera behind the character */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class USpringArmComponent* CameraBoom;

	/** Follow camera */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class UCameraComponent* FollowCamera;
public:
	ASimpleThreadTestCharacter();

	/** Base turn rate, in deg/sec. Other scaling may affect final turn rate. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category=Camera)
	float BaseTurnRate;

	/** Base look up/down rate, in deg/sec. Other scaling may affect final rate. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category=Camera)
	float BaseLookUpRate;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TArray<FSoftObjectPath> ObjectPath;
public:
	//Create a thread and bind tasks, but do not execute. Use join and detach to decide whether to execute asynchronously or synchronously; 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadProxyManageBind();

	//Creating threads and executing tasks directly is the fastest asynchronous way 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadProxyManageCreate();
	
	//Using task threads, you can put tasks into threads continuously 
	//If there is an empty thread added to the task queue, the task can be executed directly; 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadTaskManagementBind();

	//The usage is similar to that of agent thread. Let's take a look at createxxx          
	//Createxxx directly finds idle threads in the online process pool to run the current task directly; 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadTaskManagementCreate();

	//Synchronization binding will block the startup thread and activate it after completing the task 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadAbandonableManageBind();

	//Asynchronous binding is started directly and destroyed automatically after the task is completed; 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadAbandonableManageCreate();

	//Synchronous Macro
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void SynchronousMacro();

	//Asynchronous Macro
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void AsynchronousMacro();

	//After binding, you can set the time and how long to execute 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void CoroutinesManageBind();

	//After binding, a handle is returned, and the programmer decides when to execute it; 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void CoroutinesManageCreate();

	//Windows Platform Thread
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void WindowsPlatformThread();

	//Synch
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ResourceLoadingManageSynch();

	//ASynch
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ResourceLoadingManageASynch();

	//Call main thread only 
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadGraphManage_CallMainTread();

	//Call Any Thread
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void ThreadGraphManage_CallAnyThread();

	//Other Thread
	UFUNCTION(BlueprintCallable, Category = SimpleThread)
	void OtherThread();

public:
	//���� UObject
	UFUNCTION()
		void TestUObject(int32 Value);
	//���� UFunction
	UFUNCTION()
		void TestUFunction(int32 Value, FString Mes);

	UFUNCTION()
		void TimeCall();

	UFUNCTION()
	void CoroutinesCall();

	UFUNCTION()
		void Run();

	UFUNCTION()
		void OK();

protected:

	/** Resets HMD orientation in VR. */
	void OnResetVR();

	/** Called for forwards/backward input */
	void MoveForward(float Value);

	/** Called for side to side input */
	void MoveRight(float Value);

	/** 
	 * Called via input to turn at a given rate. 
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired turn rate
	 */
	void TurnAtRate(float Rate);

	/**
	 * Called via input to turn look up/down at a given rate. 
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired turn rate
	 */
	void LookUpAtRate(float Rate);

	/** Handler for when a touch input begins. */
	void TouchStarted(ETouchIndex::Type FingerIndex, FVector Location);

	/** Handler for when a touch input stops. */
	void TouchStopped(ETouchIndex::Type FingerIndex, FVector Location);

protected:
	// APawn interface
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	// End of APawn interface

public:
	/** Returns CameraBoom subobject **/
	FORCEINLINE class USpringArmComponent* GetCameraBoom() const { return CameraBoom; }
	/** Returns FollowCamera subobject **/
	FORCEINLINE class UCameraComponent* GetFollowCamera() const { return FollowCamera; }
};

